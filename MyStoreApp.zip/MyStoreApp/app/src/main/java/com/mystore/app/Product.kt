package com.mystore.app

/**
 * نوع السعر اللي المستخدم يختاره وقت الإضافة للسلة
 */
enum class PriceType(val label: String) {
    ORIGINAL("السعر الأصلي"),
    RETAIL("سعر الفصال"),
    WHOLESALE("سعر الجملة")
}

/**
 * صف واحد من ملف المنتجات (الملف الأول)
 * ترتيب الأعمدة في الإكسيل:
 * 0: اسم المنتج
 * 1: السعر الأصلي
 * 2: سعر الفصال
 * 3: سعر الجملة
 * 4: صورة المنتج (مسار أو اسم نصي فقط)
 * 5: الباركود
 */
data class Product(
    val rowIndex: Int,
    val name: String,
    val originalPrice: Double,
    val retailPrice: Double,
    val wholesalePrice: Double,
    val imageInfo: String,
    val barcode: String
) {
    fun priceFor(type: PriceType): Double = when (type) {
        PriceType.ORIGINAL -> originalPrice
        PriceType.RETAIL -> retailPrice
        PriceType.WHOLESALE -> wholesalePrice
    }
}
